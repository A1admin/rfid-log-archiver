// MyUnknown.h

#ifndef __MY_UNKNOWN_H
#define __MY_UNKNOWN_H

#include "MyWindows.h"

/*
#ifdef _WIN32
#include <basetyps.h>
#include <unknwn.h>
#else
#include "MyWindows.h"
#endif
*/
  
#endif
